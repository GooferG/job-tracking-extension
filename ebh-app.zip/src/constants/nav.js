export const nav = [
  { name: "Follow us on Twitter", action: "twitter" },
  { name: "Logout", action: "logout" },
];

export const mainNav = {
  Dashboard: "Dashboard",
  Apply: "Apply",
  Applications: "Applications",
  CoverLetter: "Cover Letter",
  Profile: "Profile",
};
