export const printLine = (line) => {
  console.log('===> FROM THE PRINT MODULE:', line);
};
